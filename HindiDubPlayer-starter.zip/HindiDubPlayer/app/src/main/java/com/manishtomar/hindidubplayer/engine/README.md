# AI engine adapters

Implement these interfaces in separate files so the playback UI does not depend on a specific AI vendor/model:

- `VideoAudioDecoder`: MediaExtractor + MediaCodec (or FFmpeg) from the selected video URI.
- `SpeechRecognizer`: local Whisper/whisper.cpp runtime.
- `Translator`: local English→Hindi model such as IndicTrans2/NLLB, or an optional network adapter.
- `HindiTts`: Piper/local Hindi TTS or Android TTS.

Do not feed microphone/speaker capture to ASR. The decoder must read the video's audio track directly.

The production mixer should schedule each Hindi PCM segment at its timestamp while keeping the original video audio source at a separate gain. The ASR path receives the original PCM before output gain is applied.
