# Hindi Dub Player — Android starter

A starter Android project for a local-video English→Hindi dubbing player.

## Current MVP
- Pick a local video with Android's document picker.
- Play it with Jetpack Media3/ExoPlayer.
- UI already has separate Original English and Hindi voice gain sliders.
- Keeps source video access through a content URI.

## Important architecture
The translator must read the **audio track from the selected video file**, not microphone/speaker output. The intended pipeline is:

`local video URI -> audio demux/decode -> streaming ASR -> English→Hindi translation -> Hindi TTS -> timestamped mixer -> playback`

The original source PCM must remain independent of the Original-output slider. Therefore setting Original to 0% should mute only what the user hears, not what ASR receives.

## Next implementation stages
1. Add MediaExtractor/MediaCodec (or FFmpeg) audio decoding to PCM.
2. Add an on-device ASR adapter (Whisper.cpp or another local Whisper runtime).
3. Add an English→Hindi translation adapter (local IndicTrans2/NLLB, or an optional API adapter).
4. Add local Hindi TTS (Piper or Android TTS).
5. Add a timestamped Hindi audio queue and mixer with two independent gains.
6. Add seek/pause synchronization and buffering.
7. Add optional export: video track + generated Hindi audio track.

## Build
Open this folder in Android Studio. Use JDK 17 and an Android SDK 36 installation. AGP 9.3.0 is used in this starter.
