package com.manishtomar.hindidubplayer

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HindiDubApp() }
    }
}

@Composable
private fun HindiDubApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var originalGain by remember { mutableFloatStateOf(1f) }
    var hindiGain by remember { mutableFloatStateOf(1f) }
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        videoUri = uri
        context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        player.setMediaItem(MediaItem.fromUri(uri)); player.prepare(); player.playWhenReady = true
    }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Hindi Dub Player") }) }) { pad ->
            Column(Modifier.padding(pad).padding(12.dp).fillMaxSize()) {
                Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) { Text("Select local video") }
                Spacer(Modifier.height(12.dp))
                AndroidView(factory = { PlayerView(it).apply { this.player = player } }, modifier = Modifier.fillMaxWidth().aspectRatio(16f/9f))
                Spacer(Modifier.height(12.dp))
                Text("Original English output: ${(originalGain * 100).toInt()}%")
                Slider(value = originalGain, onValueChange = { originalGain = it; player.volume = it }, valueRange = 0f..1f)
                Text("Hindi translated voice: ${(hindiGain * 200).toInt()}%")
                Slider(value = hindiGain, onValueChange = { hindiGain = it }, valueRange = 0f..2f)
                Spacer(Modifier.height(8.dp))
                Text("AI status: engine not connected yet")
                Text("Architecture: video file audio → ASR → English→Hindi → TTS → mixed playback")
                if (videoUri != null) Text("Selected: ${videoUri!!.lastPathSegment ?: "video"}")
            }
        }
    }
}
