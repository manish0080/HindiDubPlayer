package com.manishtomar.hindidubplayer.engine

/** Timestamped English speech segment decoded from the VIDEO FILE audio track. */
data class SpeechSegment(val startMs: Long, val endMs: Long, val english: String)

data class HindiSegment(val startMs: Long, val endMs: Long, val text: String, val pcm: ShortArray? = null)

interface VideoAudioDecoder {
    /** Emits PCM frames with timestamps. This must use the selected video URI, never microphone capture. */
    suspend fun decode(uri: android.net.Uri, onPcm: suspend (timestampMs: Long, pcm: ShortArray, sampleRate: Int, channels: Int) -> Unit)
}

interface SpeechRecognizer {
    suspend fun recognize(pcm: ShortArray, sampleRate: Int, channels: Int): String
}

interface Translator {
    suspend fun englishToHindi(text: String): String
}

interface HindiTts {
    suspend fun synthesize(text: String, sampleRate: Int = 24000): ShortArray
}

/**
 * Pipeline coordinator. Plug Whisper/IndicTrans/Piper (or API adapters) into the interfaces above.
 */
class DubbingEngine(
    private val decoder: VideoAudioDecoder,
    private val asr: SpeechRecognizer,
    private val translator: Translator,
    private val tts: HindiTts
) {
    suspend fun process(uri: android.net.Uri, onHindi: suspend (HindiSegment) -> Unit) {
        decoder.decode(uri) { timestamp, pcm, rate, channels ->
            val english = asr.recognize(pcm, rate, channels)
            if (english.isBlank()) return@decode
            val hindi = translator.englishToHindi(english)
            val hindiPcm = tts.synthesize(hindi)
            onHindi(HindiSegment(timestamp, timestamp + 1500L, hindi, hindiPcm))
        }
    }
}
